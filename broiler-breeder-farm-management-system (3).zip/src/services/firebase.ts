import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import configData from '../../firebase-applet-config.json';

const firebaseConfig = {
  projectId: configData.projectId,
  appId: configData.appId,
  apiKey: configData.apiKey,
  authDomain: configData.authDomain,
  storageBucket: configData.storageBucket,
  messagingSenderId: configData.messagingSenderId,
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize standard Firestore cloud database client
let db: ReturnType<typeof getFirestore>;

try {
  db = getFirestore(app, configData.firestoreDatabaseId || undefined);
} catch (e) {
  console.warn('Firestore initialization notice:', e);
  db = getFirestore(app);
}

const auth = getAuth(app);

export { app, db, auth, firebaseConfig };
